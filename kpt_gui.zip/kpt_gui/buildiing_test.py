da_vinci = list()
mountain = list()
mission = list()
potter = list()

def read_file_and_extract_reviews(book):
    print("The Book Name::"+str(book))
    path = "/Users/bhaarat/Downloads/kpt_gui/book_avg_sent.txt"
    book = book.lower()
    vinci = "vinci"
    mnt = "mountain"
    pot = "potter"
    mi = "mission"
    with open(path) as f:
        content = f.readlines()
        for item in content:
            item = item.lower()
            item = item.split('\t',1)
            item = item[1].split('\n',1)
            if vinci in item[0]:
                da_vinci.append(item[0])
            if mnt in item[0]:
                mountain.append(item[0])
            if pot in item[0]:
                potter.append(item[0])
            if mi in item[0]:
                mission.append(item[0])

    if vinci in book:
        print("Vinci")
        return da_vinci
    if mnt in book:
        print("Mountain")
        return mountain
    if mi in book:
        print("MI 3")
        return mission
    if pot in book:
        print("Harry Potter")
        return potter