# -*- coding: utf-8 -*-
"""
Created on Mon Jul 31 13:37:04 2017

@author: Lenovo
"""
import buildiing_test as bt

from flask import Flask, request,render_template
from flask import Flask
from flask import request
from flask import render_template, redirect, url_for, flash
import pandas as pd
import numpy as np
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cross_validation import train_test_split
from sklearn import naive_bayes
from sklearn.metrics import roc_auc_score

app=Flask(__name__)
local_path = "/Users/bhaarat/Downloads/kpt_gui/train_data_gui.txt"

@app.route('/')
def index():
    return render_template("home.html")

@app.route('/average',methods=['GET','POST'])
def average():
    if len(request.form['menu']) > 0:
	    data = bt.read_file_and_extract_reviews(request.form['menu'])
	    the_book = request.form['menu']
	    overall = find_average(data, the_book)
	    return render_template("home.html", sentiment=overall)
    else:
        flash('Choose Book')
        return render_template("home.html", sentiment="")

@app.route('/sentiment',methods=['GET','POST'])
def sentiment():
    df, stopset, vectorizer, y, X = init_classifier()
    sentiment_list = request.form['text'].split(".")
    #print(sentiment_list)
    overall = find_average(sentiment_list, "")
    return render_template("home.html", user_sentiment=overall)

def find_average(sentiments, the_book):
    pos_list = []
    neg_list = []
    sentiment_list = []
    analyzed_sentiment = ""
    if request.method == "POST" and len(the_book) > 0:
        df, stopset, vectorizer, y, X = init_classifier()
        for i in sentiments:
            if len(i) > 0:
                single_analyzed_sentiment = find_sentiment(i, df, stopset, vectorizer, y, X)
                if single_analyzed_sentiment == "Positive":
                    pos_list.append(1)
                else:
                    neg_list.append(0)
        if len(pos_list)>len(neg_list):
            analyzed_sentiment = the_book + " is " + "Positive"
        elif len(pos_list)<len(neg_list):
            analyzed_sentiment = the_book + " is " + "Negative"
        else:
            print("Neutral")
    if request.method == "POST" and len(the_book) == 0:
        print("User Sentiments Analysis")
        df, stopset, vectorizer, y, X = init_classifier()
        for i in sentiments:
            if len(i) > 0:
                single_analyzed_sentiment = find_sentiment(i, df, stopset, vectorizer, y, X)
                if single_analyzed_sentiment == "Positive":
                    #print("Positive")
                    pos_list.append(1)
                else:
                    #print("Negative")
                    neg_list.append(0)
        
        print("Negative"+str(len(neg_list)))
        print("Positive"+str(len(pos_list)))
        
        if len(pos_list)>len(neg_list):
            analyzed_sentiment =  "POSITIVE"
        elif len(pos_list)<len(neg_list):
            analyzed_sentiment = "NEGATIVE"
        else:
            analyzed_sentiment = "NEUTRAL"
    return analyzed_sentiment

def find_sentiment(the_sentiment, df, stopset, vectorizer, y, X):
    analyzed_senti = ""

    X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=42)
    clf = naive_bayes.MultinomialNB()
    clf.fit(X_train, y_train)

    data = [the_sentiment]

    review_array = np.array(data)
    review_vector = vectorizer.transform(review_array)

    sentiment = clf.predict(review_vector)

    if sentiment == 0:
        analyzed_senti = "Negative"
    else:
        analyzed_senti = "Positive"

    return analyzed_senti

def init_classifier():
    df = pd.read_csv(local_path, sep='\t', names=['txt','liked'])
    stopset = set(stopwords.words('english'))
    vectorizer = TfidfVectorizer(use_idf=True, lowercase=True, strip_accents='ascii', stop_words=stopset)
    y = df.liked
    X =vectorizer.fit_transform(df.txt)
    return df, stopset, vectorizer, y, X

if __name__=="__main__":
    app.run(debug=True)